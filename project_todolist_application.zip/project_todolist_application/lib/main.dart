import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List Application',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        scaffoldBackgroundColor: Colors.purple.shade100,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.deepPurple,
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(fontSize: 16),
        ),
        buttonTheme: ButtonThemeData(
          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        ),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  int? _editingIndex;
  List<Task> deletedTasks = [];

  List<Task> toDoList = [
    Task(
      title: 'Midyear Project',
      description: 'Create an application',
      dateTime: DateTime.now(),
      completed: false,
    ),
    Task(
      title: 'Outline Defense',
      description: 'Review for Outline Defense',
      dateTime: DateTime.now(),
      completed: true,
    ),
    Task(
      title: 'Examination',
      description: 'Review for written examination',
      dateTime: DateTime.now(),
      completed: false,
    ),
  ];

  void _showTaskDialog([int? index]) {
    final isEditing = index != null;
    final task = isEditing ? toDoList[index!] : null;

    if (isEditing) {
      _titleController.text = task!.title;
      _descriptionController.text = task.description;
      _selectedDate = task.dateTime;
      _selectedTime = TimeOfDay(hour: task.dateTime.hour, minute: task.dateTime.minute);
      _editingIndex = index;
    } else {
      _titleController.clear();
      _descriptionController.clear();
      _selectedDate = DateTime.now();
      _selectedTime = TimeOfDay.now();
      _editingIndex = null;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          isEditing ? 'Edit Task' : 'Add Task',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: _titleController,
                  decoration: InputDecoration(
                    labelText: 'Title',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  autofocus: true,
                ),
                SizedBox(height: 12),
                TextField(
                  controller: _descriptionController,
                  decoration: InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  maxLines: 3,
                ),
                SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        'Date: ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                    SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: _selectedDate,
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101),
                        );
                        if (pickedDate != null) {
                          setState(() {
                            _selectedDate = pickedDate;
                          });
                        }
                      },
                      child: Text(
                        'Select Date',
                        style: TextStyle(
                          color: Colors.white70,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                      ),
                    )

                  ],
                ),
                SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        'Time: ${_formatTime(_selectedTime)}',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                    SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () async {
                        TimeOfDay? pickedTime = await showTimePicker(
                          context: context,
                          initialTime: _selectedTime,
                        );
                        if (pickedTime != null) {
                          setState(() {
                            _selectedTime = pickedTime;
                          });
                        }
                      },
                      child: Text(
                        'Select Time',
                        style: TextStyle(
                          color: Colors.white70,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancel', style: TextStyle(color: Colors.deepPurple)),
          ),
          ElevatedButton(
            onPressed: () {
              if (_titleController.text.isNotEmpty && _descriptionController.text.isNotEmpty) {
                setState(() {
                  if (_editingIndex != null) {
                    toDoList[_editingIndex!] = Task(
                      title: _titleController.text,
                      description: _descriptionController.text,
                      dateTime: DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day, _selectedTime.hour, _selectedTime.minute),
                      completed: toDoList[_editingIndex!].completed,
                    );
                  } else {
                    toDoList.add(Task(
                      title: _titleController.text,
                      description: _descriptionController.text,
                      dateTime: DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day, _selectedTime.hour, _selectedTime.minute),
                      completed: false,
                    ));
                  }
                  Navigator.of(context).pop();
                });
              }
            },
            child: Text(isEditing ? 'Update' : 'Add',
              style: TextStyle(
                color: Colors.white70,
              ),
            ),

            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
            ),
          ),
        ],
      ),
    );
  }

  void _checkBoxChanged(int index) {
    setState(() {
      toDoList[index].completed = !toDoList[index].completed;
    });
  }

  void _deleteTask(int index) {
    setState(() {
      deletedTasks.add(toDoList[index]);
      toDoList.removeAt(index);
    });
  }

  void _showTaskDetails(Task task) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          task.title,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Card(
                  elevation: 5,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Icon(Icons.description, color: Colors.deepPurple),
                    title: Text('Description'),
                    subtitle: Text(task.description, style: TextStyle(fontSize: 16)),
                  ),
                ),
                Card(
                  elevation: 5,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Icon(Icons.calendar_today, color: Colors.deepPurple),
                    title: Text('Date'),
                    subtitle: Text(DateFormat('yyyy-MM-dd').format(task.dateTime), style: TextStyle(fontSize: 16)),
                  ),
                ),
                Card(
                  elevation: 5,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Icon(Icons.access_time, color: Colors.deepPurple),
                    title: Text('Time'),
                    subtitle: Text(_formatTime(TimeOfDay(hour: task.dateTime.hour, minute: task.dateTime.minute)), style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Close', style: TextStyle(color: Colors.deepPurple)),
          ),
        ],
      ),
    );
  }



  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat.jm().format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ToDo List'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepPurple,
              ),
              child: Text(
                'NoteIT',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.delete, color: Colors.deepPurple),
              title: Text('Trash'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => DeletedTasksPage(
                      deletedTasks: deletedTasks,
                      onDelete: (index) {
                        setState(() {
                          deletedTasks.removeAt(index);
                        });
                      },
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return ListView.builder(
            itemCount: toDoList.length,
            itemBuilder: (context, index) {
              final task = toDoList[index];
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Slidable(
                  endActionPane: ActionPane(
                    motion: StretchMotion(),
                    children: [
                      SlidableAction(
                        onPressed: (context) => _deleteTask(index),
                        icon: Icons.delete,
                        backgroundColor: Colors.red,
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ],
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    tileColor: Colors.deepPurple,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    leading: Checkbox(
                      value: task.completed,
                      onChanged: (value) => _checkBoxChanged(index),
                      checkColor: Colors.black,
                      activeColor: Colors.white,
                      side: const BorderSide(
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      task.title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        decoration: task.completed ? TextDecoration.lineThrough : TextDecoration.none,
                        decorationColor: Colors.white,
                        decorationThickness: 2,
                      ),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.edit, color: Colors.white),
                      onPressed: () => _showTaskDialog(index),
                    ),
                    onTap: () => _showTaskDetails(task),
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showTaskDialog(),
        child: Icon(Icons.add),
      ),
    );
  }
}

class DeletedTasksPage extends StatelessWidget {
  final List<Task> deletedTasks;
  final Function(int) onDelete;

  DeletedTasksPage({required this.deletedTasks, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Deleted Tasks'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        itemCount: deletedTasks.length,
        itemBuilder: (context, index) {
          final task = deletedTasks[index];
          return ListTile(
            contentPadding: EdgeInsets.all(16),
            tileColor: Colors.deepPurple,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            title: Text(
              task.title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                decoration: task.completed ? TextDecoration.lineThrough : TextDecoration.none,
                decorationColor: Colors.white,
                decorationThickness: 2,
              ),
            ),
            subtitle: Text(
              task.description,
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          );
        },
      ),
    );
  }
}

class Task {
  String title;
  String description;
  DateTime dateTime;
  bool completed;

  Task({
    required this.title,
    required this.description,
    required this.dateTime,
    required this.completed,
  });
}
